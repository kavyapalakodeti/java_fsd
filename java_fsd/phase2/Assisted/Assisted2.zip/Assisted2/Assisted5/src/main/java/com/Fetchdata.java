package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Fetchdata
 */
public class Fetchdata extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Fetchdata() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		PrintWriter pw=response.getWriter();
		String Id=request.getParameter("id");
		int  id=  Integer.parseInt(Id);
		String Name=request.getParameter("name");
		String Salary=request.getParameter("Salary");
		
		
		response.setContentType("text/html");
		//RequestDispatcher rd1=request.getRequestDispatcher("index.html");
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			pw.println("Driver Loaded Succesfully");
			Connection con= DriverManager.getConnection("jdbc:mysql://localhost:3306/javatraining","root","Sivani@143");
			pw.println("Connected succesfully");
			PreparedStatement pstmt=con.prepareStatement("insert into details values(?,?,?)");
		
			pstmt.setInt(1, id);
			
			pstmt.setString(2, Name);
	
			pstmt.setString(3, Salary);
			int res=pstmt.executeUpdate();
			if(res>0) {
				System.out.println("Record inserted Succesfully");
			}
			
			//
			PreparedStatement pstmt1=con.prepareStatement("delete from employee where id=?");
		
		
			pstmt.setInt(1, id);
			int res1=pstmt1.executeUpdate();
			if(res1>0) {
				pw.println("Record deleted succesfully");
			}
			else
			{
				pw.println("Record not present");
			}
			//
			PreparedStatement pstmt2=con.prepareStatement("update employee set name=? where id=?");
			
			
		
			pstmt.setInt(2, id);
				pw.println("Enter salary");
		
			pstmt.setString(1, Salary);
			int res3=pstmt2.executeUpdate();
			if(res3>0) {
				pw.println("Record updated succesfully");
			}
			else
			{
				pw.println("Record not present");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			pw.println(e);
			
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
